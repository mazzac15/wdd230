#  🔒 Applied JavaScript Activity

A Pen created on CodePen.io. Original URL: [https://codepen.io/mazzac/pen/vYbOLVX](https://codepen.io/mazzac/pen/vYbOLVX).

